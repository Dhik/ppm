<footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>PPM Nurul Hakim &copy; 2020</p>
            </div>
            <div class="col-sm-6 text-right">
              <p style="font-size:1px;">Design by <a href="https://bootstrapious.com/p/bootstrap-4-dashboard" class="external">Bootstrapious</a></p>
            </div>
          </div>
        </div>
      </footer>