<footer class="site-footer">
      <div class="container">
        <div class="row text-center">
          <div class="col-md-12">
            <div class="mb-5">
              <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
            </div>
            <h6>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            PPM Nurul Hakim
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </h6>
            
          </div>
          
        </div>
      </div>
      <p style="font-size:1px;">
      <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with</i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
      </p>
    </footer>